# Audit de sécurité (phase 8, 21 octobre 2026)

Un seul passage, sur le site principal (`site/`) et sur la copie publique
(`~/Desktop/"Site Web"/_CDBA-PRIVE/CDBA-DEMO/CDBA-demo-public`). Site statique : pas de serveur applicatif,
pas de base de données, pas de dépendance npm.

## Constats

| # | Constat | Gravité | Action |
|---|---------|---------|--------|
| 1 | `frame-ancestors` (anti-clickjacking) ne peut pas être mis dans une balise meta CSP. | Moyenne | **Corrigé pour un futur hébergeur** : `site/_headers` (Netlify, Cloudflare Pages) et `site/.htaccess` (Apache) envoient la même CSP que la meta, plus `frame-ancestors 'none'`. **Laissé** sur la copie GitHub Pages (voir n° 2). |
| 2 | GitHub Pages n'envoie pas d'en-têtes personnalisés : la copie n'a que la CSP en meta, sans `frame-ancestors`, `X-Content-Type-Options` ni `Permissions-Policy`. | Moyenne (copie seulement) | **Laissé** : limite de l'hébergeur. Atténué : `Referrer-Policy` ajoutée en meta (`no-referrer`) sur les 11 pages, qui fonctionne aussi sur GitHub Pages. `_headers` n'est pas copié dans la copie. |
| 3 | HSTS : à n'activer qu'en production HTTPS, sur le domaine définitif. | Information | **Documenté**, ligne commentée dans `_headers` et `.htaccess`. GitHub Pages impose déjà HTTPS sur `*.github.io` [À VÉRIFIER : non relu dans la documentation]. |
| 4 | En-têtes `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, `Permissions-Policy` (caméra, micro, géolocalisation, paiement, USB désactivés). | Information | **Ajoutés** dans `_headers` et `.htaccess`. |
| 5 | Styles et scripts en ligne, attributs `on…=`. | — | Aucun (recherche dans le site et la copie). La CSP n'a pas besoin de `'unsafe-inline'`. |
| 6 | Secrets (clés privées, jetons GitHub, AWS, Google, Slack, OpenAI) dans les fichiers et dans **tout l'historique git** du dépôt principal. | — | Aucun trouvé. |
| 7 | Mots de passe de démonstration (`marie2026`, `paul2026`, `sophie2026`) dans `site/js/demo-comptes.js` (table) et `site/connexion/index.html` (liste affichée, demandée en phase 7). | Faible (voulu) | **Laissé** : comptes fictifs publics, ils ne protègent rien. À retirer avant la mise en ligne (`16-COMPTES-DEMO.md`). |
| 8 | Identité locale dans **l'historique du dépôt principal** : les 47 commits portent « Stojanovic Luka <stojanovicluka@air-de-luka.home> » (nom de session et nom de l'ordinateur). | Faible | **Laissé** (réécrire l'historique serait irréversible). Ne concerne pas la copie publique, qui a son propre historique avec l'identité neutre « Demo CDBA <demo@example.invalid> ». À savoir si le dépôt principal est un jour publié. |
| 9 | Noms réels d'élus relevés sur cdba.club (président, responsables de la section) dans `legal-brouillons/` et `docs/08`. | Faible | **Laissé** (documents de travail, non publiés, absents du site et de la copie). |
| 10 | `.gitignore` | Information | **Complété** : en plus de `.DS_Store`, `.env`, `.env.*`, `*.pem`, `cdba-certs/`, il couvre désormais les sauvegardes (`*~`, `*.bak`, `*.swp`, `*.orig`, `*.tmp`) et les clés (`*.key`, `*.p12`, `*.crt`). |
| 11 | Liens externes (`rel="noopener noreferrer"`), `target="_blank"`, ressources tierces, contenu mixte, formulaires avec `action` externe. | — | Aucun lien `http(s)` externe (seulement `mailto:` et `tel:`), aucun `target="_blank"`, aucune ressource `http://`, aucun attribut `action` ; CSP `form-action 'none'`. |
| 12 | Dépendances | — | Aucun `package.json` : pas de `npm audit` possible ni nécessaire. |
| 13 | Métadonnées des images (adresses cachées). | — | Aucune adresse dans `logo-cdba.png`, `murene.jpg`, `murene.webp`. |
| 14 | Cookies, `localStorage`, `sessionStorage`, IndexedDB. | — | Suite D du 21 octobre 2026, Chromium 153 et Firefox 155, 11 pages du site **et** de la copie, après connexion des trois comptes : 0 cookie, stockages vides, 0 requête vers un autre domaine. |

## Données personnelles présentes dans le site et la copie

- **Adresse e-mail :** `plongee@cdba.club` (contact de la section, 14 occurrences
  dans les fichiers suivis, dont les documents). Aucune autre adresse dans
  le site ; `demo@example.invalid` n'apparaît que dans la documentation.
- **Téléphone :** 01 40 85 81 28 (UCPA Aqua92, établissement), aucun autre.
- **Adresse postale :** celle de l'UCPA Aqua92 (établissement).
- **Noms :** uniquement des personnes fictives marquées EXEMPLE (Marie
  Exemple, Paul, Sophie, Camille, Hugo, Léa). Aucun nom réel.

## Limites propres à GitHub Pages (copie)

- Pas d'en-têtes HTTP personnalisés : CSP en meta seulement, sans
  `frame-ancestors` (la page peut être intégrée dans un cadre par un autre
  site) ni `X-Content-Type-Options`.
- `noindex` et `Disallow: /` demandent aux moteurs de ne pas référencer, mais
  n'empêchent pas l'accès : le site reste public.

## Régénérer la copie

`python3 -I outils/copie-publique.py ~/Desktop/"Site Web"/_CDBA-PRIVE/CDBA-DEMO/CDBA-demo-public` refait la
copie depuis `site/` avec les mêmes transformations, en préservant son `.git`
et sans copier les fichiers cachés ni `_headers`.
