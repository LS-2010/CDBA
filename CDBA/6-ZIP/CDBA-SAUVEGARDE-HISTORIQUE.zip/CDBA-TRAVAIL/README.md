# CDBA — site de la section plongée (maquette)

Site statique de la section plongée et apnée du Club Défense Balard Arcueil
(CDBA) : pages publiques (dates des fosses, lieu, horaires, niveaux, tarifs,
inscription), pages légales **provisoires**, et **maquette** des espaces
adhérent, moniteur et administrateur.

Ce n'est pas la version finale. Rien n'est en ligne. Les erreurs et réserves
connues sont listées plus bas (« Points connus »).

## Structure

| Dossier | Contenu |
|---------|---------|
| `site/` | Le site : pages HTML, `css/style.css`, `js/`, `img/`, fichiers de serveur (`_headers`, `.htaccess`, `robots.txt`, `sitemap.xml`). |
| `site/connexion/` | Page de connexion de la maquette (comptes fictifs). |
| `site/espace-demo/`, `site/espace-moniteur-demo/`, `site/espace-admin-demo/` | Maquettes des espaces adhérent, moniteur, administrateur. |
| `docs/` | Rapports de phase, charte, conformité, audit de sécurité, inventaire des données, captures avant/après. Numérotés dans l'ordre de rédaction. |
| `outils/` | Scripts Python (voir plus bas). |
| `tests/` | Tests Playwright (débordement horizontal, erreurs de pages, clavier, comptes de démo). Voir `tests/README.md`. |
| `legal-brouillons/` | Brouillons juridiques (mentions légales, confidentialité, mention de formulaire). Lire `legal-brouillons/LISEZ-MOI.md` avant tout usage. |
| `sources/` | Fichiers d'origine non publiés (photo de la murène avant retouche). |

Pas de dépendance à installer : HTML, CSS et JavaScript sans framework ni
étape de construction. Les outils n'utilisent que la bibliothèque standard
de Python 3 (et `rsync`, présent sur macOS).

## Lancer le site en local

```sh
cd site
python3 -m http.server 8091 --bind 127.0.0.1
```

Puis ouvrir http://127.0.0.1:8091 . Arrêt : Ctrl+C.

Le site s'ouvre aussi par double-clic sur `site/index.html` (protocole
`file://`, vérifié en phase 9 dans Chromium et Firefox).

Les en-têtes de `_headers` et `.htaccess` ne sont **pas** appliqués par
`http.server` ; la CSP est aussi présente en `<meta>` dans les pages.

## Lancer les tests

Sept tests Playwright (Chromium ou Firefox) sont dans `tests/` : défilement horizontal
de 320 à 5120 px, erreurs de console ou ressources en 404, parcours au clavier,
connexion des comptes de démo, contraste du texte, taille des cibles tactiles, section « Niveaux » et
dates modifiables de l'espace administrateur.
Installation et lancement : `tests/README.md`.

Les autres vérifications des phases précédentes (Lighthouse, formulaires…) ont été faites avec des scripts non
versionnés et ne sont pas reprises ; leurs résultats sont décrits dans
`docs/11-RAPPORT-PHASE-5.md` et `docs/17-BILAN-V1.md` (section 3). Les deux
outils Python contiennent leurs propres contrôles (`assert`) et s'arrêtent en
cas d'écart.

## Fichiers Python

Liste complète (il n'y en a que deux) :

| Fichier | Rôle |
|---------|------|
| `outils/copie-publique.py` | Régénère la copie publique de démonstration (GitHub Pages) depuis `site/` : copie par `rsync` sans fichiers cachés, sans `_headers` ni `sitemap.xml`, retire la canonique, ajoute `noindex, nofollow`, un bandeau « Version de démonstration » et un `robots.txt` qui bloque tout. Garde le `.git` de la copie. Usage : `python3 -I outils/copie-publique.py <dossier-de-la-copie>`. Voir `docs/17-COPIE-PUBLIQUE-GITHUB.md`. |
| `outils/poc-hors-ligne.py` | Fabrique l'archive hors ligne `CDBA-POC.zip` (pages, `css/`, `js/`, `img/`, `LISEZ-MOI.txt`) à ouvrir par double-clic, sans serveur. Exclut fichiers cachés et fichiers de serveur. Usage : `python3 -I outils/poc-hors-ligne.py <chemin>/CDBA-POC.zip`. |

Les deux scripts trouvent `site/` par rapport à leur propre emplacement : ils
fonctionnent quel que soit le dossier de clonage.

## Ce qui est simulé

- **Connexion fictive** : `site/js/demo-comptes.js` compare trois comptes de
  démonstration **dans le navigateur** (Marie adhérente, Paul moniteur,
  Sophie administratrice ; codes dans `docs/16-COMPTES-DEMO.md`). Ce n'est
  pas une authentification : les codes sont lisibles dans le code source,
  et chaque espace est accessible directement par son adresse.
- **Aucune donnée réelle** : les dossiers, inscrits, fiches et palanquées
  sont des données EXEMPLE écrites dans les pages. Rien n'est envoyé, rien
  n'est stocké (ni cookie, ni stockage local) ; les modifications (rôles,
  forfaits, palanquées) ne vivent qu'en mémoire jusqu'au rechargement.
- Formulaires (inscription à une fosse, mot de passe, mot de passe oublié,
  création de compte) : ils vérifient les champs mais n'envoient rien ;
  certains boutons sont volontairement inactifs.

## Ce qui reste à construire

- **API** (côté serveur) : aucune n'existe. Les besoins par fonctionnalité
  (profil, inscriptions, palanquées, rôles, forfaits) et ce que la vraie V1
  exigera sont listés dans `docs/20-CR-FONCTIONNALITES.md` (section
  « Exigences du compte rendu : statut »).
- **Vraie authentification** : hébergement, comptes créés par
  l'administrateur, stockage des mots de passe, limitation des tentatives,
  cookie de session, durée de conservation : `docs/13-VRAIE-AUTHENTIFICATION.md`.
- **Base de données** : données à stocker, qui les saisit, qui y accède,
  durées : `docs/22-INVENTAIRE-DONNEES.md`. Les droits par rôle devront être
  vérifiés côté serveur (une page cachée ne protège rien).
- Avant toute mise en ligne : retirer les comptes de démonstration
  (`docs/16-COMPTES-DEMO.md`), retirer la maquette (`docs/09-RETIRER-MAQUETTE.md`)
  et suivre la liste « avant mise en ligne » de `docs/12-CONFORMITE.md`.

## Points connus

Erreurs et réserves déjà identifiées, non corrigées volontairement :

- **Marqueurs ouverts** : de nombreux `[À CONFIRMER]`, `[À COMPLÉTER]` et
  `[À VÉRIFIER]` dans `site/`, `docs/` et `legal-brouillons/` (décompte au
  21 octobre 2026 dans `docs/17-BILAN-V1.md`, section 5). Ils attendent des
  réponses du club ; aucun n'a été comblé par une valeur inventée.
- **Pages légales provisoires** : mentions légales incomplètes (forme
  juridique, RNA/SIREN, siège, directeur de la publication, hébergeur),
  confidentialité et conditions à valider, droit de rétractation à confirmer.
- **Safari / WebKit non testé** : le site a été chargé dans Safari 26.6.1
  en HTTPS local, mais le rendu n'a pas été regardé et la connexion pas
  essayée. Non testés non plus : vrai iPhone, vrai Android, Samsung
  Internet, VoiceOver, TalkBack.
- **Edge non testé** : Microsoft Edge n'est pas installé sur le Mac de
  développement ; Windows, Linux et ChromeOS réels non testés non plus. Le
  mode contraste élevé (`forced-colors`) n'a pas été vu à l'écran.
  L'impression a été vérifiée en PDF Chromium (accueil, espace adhérent).
- **Domaine inconnu** : `domaine-a-confirmer.example` sert de remplissage
  dans `sitemap.xml` et `robots.txt` ; la canonique est relative. D'où un
  score SEO Lighthouse de 85 (avec `robots.txt` illisible par Lighthouse à
  cause de la CSP).
- **Forfait** : incohérence « toutes les fosses » / « 5 fosses » à trancher
  par le club. Lieu de l'apnée absent ; année d'une date d'apnée (6 juin)
  à vérifier sur cdba.club.
- **Droits** du logo (marque de la Fédération) et de la photo de la murène :
  à confirmer par écrit.
- **Tests** : seuls deux contrôles sont repris dans `tests/` (voir « Lancer les tests ») ; un script
  de compatibilité attendait encore un ancien message (« inscription
  complète » pour un mineur), écart d'outil noté dans `docs/17-BILAN-V1.md`.
- **Documentation** : deux documents portent le numéro 17
  (`17-BILAN-V1.md`, `17-COPIE-PUBLIQUE-GITHUB.md`) et il n'y a pas de
  `21` [À CONFIRMER : document jamais écrit ou retiré]. Les docs citent
  l'emplacement du Mac de développement (`~/Desktop/"Site Web"/_CDBA-PRIVE/CDBA-TRAVAIL/` et `CDBA-DEMO/`) ; adapter au dossier de clonage.
- La copie publique (`CDBA-demo-public`) et l'archive POC sont hors de ce
  dépôt ; elles se régénèrent avec les outils ci-dessus.
